/**
 * ===================================================================
 *  แพลตฟอร์ม Merge เอกสารราชการ (หนังสือราชการ / คำสั่ง / ประกาศ ฯลฯ)
 *  - Google Sheets + Apps Script
 *  - ส่งออกเป็น Word (.docx) โดยตรง รูปแบบไม่เพี้ยน
 *  - แทนค่าได้ทั้งเนื้อหา หัวกระดาษ และท้ายกระดาษ
 *  - รองรับทั้ง MERGEFIELD และ {{ชื่อฟิลด์}}
 * ===================================================================
 */

/* ============================== ค่าคงที่ ============================== */
var DATA_SHEET_NAME     = 'ข้อมูล';
var TEMPLATE_SHEET_NAME = 'แม่แบบ';
var CONFIG_SHEET_NAME   = 'ตั้งค่า';
var ALIAS_SHEET_NAME    = 'นามแฝงฟิลด์';

var CHECKBOX_COL_NAME = 'เลือก';
var TEMPLATE_COL_NAME = 'แม่แบบ'; // คอลัมน์ในชีท "ข้อมูล" ที่เลือกแม่แบบรายแถว (ถ้ามี)

var TEMPLATE_START_ROW = 2; // ชีท "แม่แบบ": แถวข้อมูลเริ่มที่ 2 (แถว 1 = หัวตาราง)

// ชนิดไฟล์ Word (OOXML) — บังคับให้ผลลัพธ์เป็น .docx จริง ไม่แปลงเป็น Google เอกสาร
var WORD_MIME = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';

// ทะเบียนคุม (สถานะ/SLA)
var TRACKING_COLUMNS = ['วันที่รับเรื่อง', 'กำหนดเสร็จ', 'สถานะ', 'วันที่ดำเนินการแล้วเสร็จ', 'หมายเหตุ'];
var STATUS_LIST = ['รับเรื่องแล้ว', 'กำลังดำเนินการ', 'รอข้อมูลเพิ่มเติม', 'เสร็จสิ้น', 'ตีกลับ'];
var STATUS_DONE = 'เสร็จสิ้น';

/* ============================== เมนู ============================== */
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('📨 แพลตฟอร์มเอกสาร')
    .addItem('🖥️ เปิด/สร้างแผงปุ่มควบคุม', 'createControlPanel')
    .addSeparator()
    .addItem('🔀 สร้างเอกสารจากแถวที่เลือก...', 'showMergeDialog')
    .addItem('🧩 สแกนฟิลด์ในแม่แบบ (ตรวจชื่อฟิลด์)', 'scanTemplateFields')
    .addSeparator()
    .addItem('⚙️ ติดตั้ง/สร้างชีตเริ่มต้น', 'initSheets')
    .addItem('➕ เพิ่มคอลัมน์ Checkbox เลือกแถว', 'addCheckboxColumn')
    .addItem('📋 เพิ่มทะเบียนคุม (สถานะ/SLA)', 'setupTrackingColumns')
    .addItem('🔎 ตรวจความพร้อม', 'runHealthCheck')
    .addItem('❓ วิธีใช้งาน', 'showHelp')
    .addToUi();
}

function showHelp() {
  var ui = SpreadsheetApp.getUi();
  ui.alert('วิธีใช้งานโดยย่อ',
    '1) ทำเทมเพลต Word (.docx) โดยวางฟิลด์เป็น {{ชื่อฟิลด์}} หรือ MERGEFIELD ในตำแหน่งที่ต้องการ\n' +
    '   (ใช้ในหัวกระดาษ/ท้ายกระดาษได้) — ชื่อในวงเล็บต้องตรงกับหัวคอลัมน์ในชีท "ข้อมูล"\n' +
    '2) อัปโหลดเทมเพลตขึ้น Google Drive (เก็บเป็น .docx) แล้วคัดลอก File ID\n' +
    '3) ชีท "แม่แบบ": ใส่ ชื่อแม่แบบ | File ID | รูปแบบชื่อไฟล์ (ใส่ {{ฟิลด์}} ได้)\n' +
    '4) ชีท "ตั้งค่า": ใส่ Output Folder ID (โฟลเดอร์เก็บผลลัพธ์)\n' +
    '5) ชีท "ข้อมูล": กรอกข้อมูล 1 แถว = 1 เอกสาร (มีคอลัมน์ "แม่แบบ" เลือกได้ว่าจะใช้แม่แบบไหน)\n' +
    '6) เมนู "➕ เพิ่มคอลัมน์ Checkbox" → ติ๊กแถว → "🔀 สร้างเอกสารจากแถวที่เลือก..."\n' +
    '7) กดปุ่ม "⬇️ ดาวน์โหลด Word" ได้ไฟล์ .docx ทันที (รูปแบบไม่เพี้ยน)\n\n' +
    'เคล็ดลับ: เมนู "🧩 สแกนฟิลด์ในแม่แบบ" จะตรวจว่าฟิลด์ในเทมเพลตตรงกับหัวคอลัมน์หรือไม่',
    ui.ButtonSet.OK);
}

/* ===================== แผงปุ่มควบคุมบนหน้าชีต ===================== */
var PANEL_SHEET_NAME = '🖥️ แผงควบคุม';

function createControlPanel() {
  var ui = SpreadsheetApp.getUi();
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var old = ss.getSheetByName(PANEL_SHEET_NAME);
  if (old) ss.deleteSheet(old);
  var sh = ss.insertSheet(PANEL_SHEET_NAME, 0);

  sh.setHiddenGridlines(true);
  // ความกว้างคอลัมน์: A=ขอบ, B-D=ปุ่มซ้าย, E=ช่องว่าง, F-H=ปุ่มขวา, I=ขอบ
  var widths = { 1: 26, 2: 150, 3: 150, 4: 70, 5: 26, 6: 150, 7: 150, 8: 70, 9: 20 };
  Object.keys(widths).forEach(function (c) { sh.setColumnWidth(Number(c), widths[c]); });

  // แบนเนอร์
  merge_(sh, 'B2:H2', '#1a73e8', '#ffffff', '📨  แพลตฟอร์มจัดทำเอกสารราชการ', 20, 'left');
  merge_(sh, 'B3:H3', '#1a73e8', '#e8f0fe', 'สร้างหนังสือราชการ / คำสั่ง / ประกาศ  →  ส่งออก Word (.docx) รูปแบบไม่เพี้ยน', 12, 'left');
  sh.setRowHeight(2, 44); sh.setRowHeight(3, 26); sh.setRowHeight(4, 14);

  // ปุ่มหลัก (HERO)
  tile_(sh, 'B5:H7', '#1a73e8', '#0b4aa2', '#ffffff', '🔀   สร้างเอกสาร Word จากแถวที่เลือก', 18,
        'ปุ่มหลัก — กำหนดสคริปต์: showMergeDialog');
  merge_(sh, 'B8:H8', '#ffffff', '#5f6368',
        'ติ๊กแถวที่ต้องการในชีท “ข้อมูล” แล้วกดปุ่มนี้เพื่อเริ่มสร้างเอกสาร', 11.5, 'left');
  [5, 6, 7].forEach(function (r) { sh.setRowHeight(r, 34); });
  sh.setRowHeight(8, 22); sh.setRowHeight(9, 14);

  // ปุ่มรอง (กระเบื้อง 2 คอลัมน์)
  var tiles = [
    ['B10:D12', '#e4f7fb', '#12a4af', '🧩   สแกนฟิลด์ในแม่แบบ', 'ตรวจชื่อฟิลด์ให้ตรงหัวคอลัมน์ — scanTemplateFields'],
    ['F10:H12', '#e6f4ea', '#188038', '📋   เพิ่มทะเบียนคุม', 'สถานะ / SLA / วันครบกำหนด — setupTrackingColumns'],
    ['B14:D16', '#fef7e0', '#f9ab00', '➕   เพิ่มคอลัมน์ Checkbox', 'ไว้ติ๊กเลือกแถวที่จะสร้าง — addCheckboxColumn'],
    ['F14:H16', '#e8f0fe', '#1a73e8', '🔎   ตรวจความพร้อม', 'เช็กโฟลเดอร์ / File ID แม่แบบ — runHealthCheck'],
    ['B18:D20', '#f1f3f4', '#80868b', '⚙️   ติดตั้ง / สร้างชีตเริ่มต้น', 'สร้างชีตทั้งหมดให้อัตโนมัติ — initSheets'],
    ['F18:H20', '#fce8e6', '#d93025', '❓   วิธีใช้งาน', 'คู่มือย่อในหน้าต่างเดียว — showHelp']
  ];
  tiles.forEach(function (t) { tile_(sh, t[0], t[1], t[2], '#202124', t[3], 15.5, t[4]); });
  [10, 11, 12, 14, 15, 16, 18, 19, 20].forEach(function (r) { sh.setRowHeight(r, 26); });
  [13, 17].forEach(function (r) { sh.setRowHeight(r, 12); });
  sh.setRowHeight(21, 14);

  // กล่องวิธีทำให้ปุ่มกดได้
  merge_(sh, 'B22:H24', '#fffbe6', '#665200',
    '🔧 ทำให้ปุ่มกดได้ (ทำครั้งเดียว):  แทรก ▸ ภาพวาด  →  วาดรูปปุ่มแล้วกด “บันทึกและปิด”  →  ' +
    'คลิกที่รูป  →  จุด 3 จุด (⋮)  →  “กำหนดสคริปต์”  →  พิมพ์ชื่อฟังก์ชัน (ดูที่หมายเหตุมุมเซลล์ปุ่ม เช่น showMergeDialog)\n' +
    'หรือใช้เมนู “📨 แพลตฟอร์มเอกสาร” ด้านบนได้ทันทีโดยไม่ต้องตั้งค่า', 12, 'left');
  sh.getRange('B22:H24').setBorder(true, true, true, true, false, false, '#ffd666', SpreadsheetApp.BorderStyle.SOLID);
  [22, 23, 24].forEach(function (r) { sh.setRowHeight(r, 24); });

  sh.getRange('A1:I25').setFontFamily('Sarabun');
  ss.setActiveSheet(sh); sh.setActiveSelection('A1');

  ui.alert('สร้างแผงปุ่มควบคุมแล้ว ✅',
    'ปุ่มทุกอันใช้งานได้ผ่านเมนู “📨 แพลตฟอร์มเอกสาร” ทันที\n\n' +
    'ถ้าต้องการให้ “คลิกที่ปุ่มบนชีตแล้วทำงานเลย” ให้ทำครั้งเดียวตามกล่องสีเหลืองด้านล่างแผง ' +
    '(แทรกภาพวาดทับปุ่ม แล้วกำหนดสคริปต์ตามชื่อในหมายเหตุมุมเซลล์)',
    ui.ButtonSet.OK);
}

// เซลล์ข้อความธรรมดา (merge + จัดรูปแบบ)
function merge_(sh, a1, bg, fg, text, size, halign) {
  var r = sh.getRange(a1); r.merge();
  r.setBackground(bg).setFontColor(fg).setValue(text)
   .setFontSize(size).setVerticalAlignment('middle')
   .setHorizontalAlignment(halign || 'left').setWrap(true);
  return r;
}

// ปุ่ม (merge + พื้นสี + เส้นขอบซ้ายหนาสีเน้น + หมายเหตุชื่อฟังก์ชัน)
function tile_(sh, a1, bg, accent, fg, text, size, note) {
  var r = sh.getRange(a1);
  r.merge();
  r.setBackground(bg).setFontColor(fg).setValue(text)
   .setFontSize(size).setFontWeight('bold')
   .setVerticalAlignment('middle').setHorizontalAlignment('left').setWrap(true);
  r.setBorder(true, true, true, true, false, false, '#e0e0e0', SpreadsheetApp.BorderStyle.SOLID);
  r.setBorder(null, true, null, null, null, null, accent, SpreadsheetApp.BorderStyle.SOLID_THICK);
  if (note) r.setNote(note);
  return r;
}

/* ===================== เครื่องยนต์ Merge (.docx) ===================== */

// แทนค่า MERGEFIELD ในย่อหน้าเดียว (คงรูปแบบเดิมไว้)
function processParaMergeFields_(pxml, dataMap, aliasMap, report) {
  var runRe = /<w:r\b[^>]*>[\s\S]*?<\/w:r>/g;
  var out = [], last = 0, m;
  var state = 'normal', instr = '', iR = null, rR = null;
  function finalize() {
    var name = parseFieldName_(instr);
    var real = aliasMap[name] || name;
    var val = (dataMap[real] !== undefined) ? dataMap[real]
            : (dataMap[name] !== undefined ? dataMap[name] : '');
    if (name && dataMap[real] === undefined && dataMap[name] === undefined) report.unknown[name] = true;
    var pr = (rR !== null) ? rR : (iR || '');
    out.push('<w:r>' + pr + '<w:t xml:space="preserve">' + escapeXml_(val) + '</w:t></w:r>');
  }
  while ((m = runRe.exec(pxml)) !== null) {
    var run = m[0];
    out.push(pxml.substring(last, m.index)); last = runRe.lastIndex;
    var b = run.indexOf('fldCharType="begin"') !== -1;
    var s = run.indexOf('fldCharType="separate"') !== -1;
    var e = run.indexOf('fldCharType="end"') !== -1;
    var it = run.match(/<w:instrText[^>]*>([\s\S]*?)<\/w:instrText>/);
    if (state === 'normal') {
      if (b) { state = 'i'; instr = ''; iR = null; rR = null; } else out.push(run);
    } else if (state === 'i') {
      if (it) instr += it[1];
      if (iR === null) iR = getRpr_(run);
      if (s) state = 'r'; else if (e) { finalize(); state = 'normal'; }
    } else if (state === 'r') {
      if (e) { finalize(); state = 'normal'; } else if (rR === null) rR = getRpr_(run);
    }
  }
  out.push(pxml.substring(last));
  return out.join('');
}

// รวม run ที่ติดกันและมีรูปแบบ (rPr) เหมือนกัน -> ช่วยให้ {{ฟิลด์}} ที่ถูก Word ตัดคนละ run กลับมาต่อกัน
function rebuildMergeRuns_(pxml) {
  var runRe = /<w:r\b[^>]*>[\s\S]*?<\/w:r>/g;
  var arr = [], pos = [], m;
  while ((m = runRe.exec(pxml)) !== null) { arr.push(m[0]); pos.push([m.index, runRe.lastIndex]); }
  function simple(r) {
    if (r.indexOf('fldChar') !== -1 || r.indexOf('instrText') !== -1 ||
        r.indexOf('<w:br') !== -1 || r.indexOf('<w:tab') !== -1) return null;
    var t = r.match(/<w:t\b[^>]*>([\s\S]*?)<\/w:t>/);
    return t ? t[1] : null;
  }
  var out = [], last = 0, i = 0;
  while (i < arr.length) {
    var txt = simple(arr[i]);
    if (txt === null) { i++; continue; }
    var rpr = getRpr_(arr[i]), text = txt, j = i + 1;
    while (j < arr.length && getRpr_(arr[j]) === rpr && simple(arr[j]) !== null) { text += simple(arr[j]); j++; }
    if (j > i + 1) {
      out.push(pxml.substring(last, pos[i][0]));
      out.push('<w:r>' + rpr + '<w:t xml:space="preserve">' + text + '</w:t></w:r>');
      last = pos[j - 1][1];
    }
    i = j;
  }
  out.push(pxml.substring(last));
  return out.join('');
}

// แทนค่า {{ฟิลด์}} ภายในโหนดข้อความ <w:t> (คงรูปแบบเดิมไว้)
function replacePlaceholders_(xml, dataMap, aliasMap, report) {
  return xml.replace(/(<w:t\b[^>]*>)([\s\S]*?)<\/w:t>/g, function (full, open, inner) {
    var neu = inner.replace(/\{\{\s*([^}]+?)\s*\}\}/g, function (mm, key) {
      key = key.trim();
      var real = aliasMap[key] || key;
      if (dataMap[real] !== undefined) return escapeXml_(dataMap[real]);
      if (dataMap[key] !== undefined) return escapeXml_(dataMap[key]);
      report.unresolved[key] = true;
      return mm;
    });
    return open + neu + '</w:t>';
  });
}

function processPartXml_(xml, dataMap, aliasMap, report) {
  xml = xml.replace(/<w:p\b[^>]*>[\s\S]*?<\/w:p>/g, function (p) { return processParaMergeFields_(p, dataMap, aliasMap, report); });
  xml = xml.replace(/<w:p\b[^>]*>[\s\S]*?<\/w:p>/g, function (p) { return rebuildMergeRuns_(p); });
  xml = replacePlaceholders_(xml, dataMap, aliasMap, report);
  return xml;
}

// สร้างไฟล์ Word จากเทมเพลต — ประมวลผล document.xml + header*.xml + footer*.xml
function mergeDocxTemplate_(fileId, dataMap, aliasMap, folder, outBaseName) {
  var templateFile = DriveApp.getFileById(fileId);
  var blob = templateFile.getBlob().setContentType('application/zip');
  var blobs = Utilities.unzip(blob);
  var report = { unknown: {}, unresolved: {} };
  var partRe = /^word\/(document|header\d*|footer\d*)\.xml$/;

  var newBlobs = [];
  for (var i = 0; i < blobs.length; i++) {
    var b = blobs[i], name = b.getName();
    if (partRe.test(name)) {
      var xml = b.getDataAsString('UTF-8');
      xml = processPartXml_(xml, dataMap, aliasMap, report);
      newBlobs.push(Utilities.newBlob(xml, 'application/xml').setName(name));
    } else {
      newBlobs.push(b);
    }
  }
  var finalName = outBaseName + '.docx';
  var zipBlob = Utilities.zip(newBlobs).setName(finalName).setContentType(WORD_MIME);
  var outFile = folder.createFile(zipBlob);
  outFile.setName(finalName);
  return { file: outFile, unknownFields: Object.keys(report.unknown), unresolved: Object.keys(report.unresolved) };
}

/* ===================== ตัวช่วย XML ===================== */
function parseFieldName_(instr) {
  var s = String(instr).replace(/^[\s\S]*?MERGEFIELD\s+/, '');
  var bs = s.indexOf('\\'); if (bs >= 0) s = s.substring(0, bs);
  s = s.trim().replace(/^"([\s\S]*)"$/, '$1');
  return s.trim();
}
function getRpr_(run) {
  var m = run.match(/<w:rPr\b[^>]*\/>|<w:rPr\b[^>]*>[\s\S]*?<\/w:rPr>/);
  return m ? m[0] : '';
}
function escapeXml_(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/* ===================== อ่านชีท/ตั้งค่า ===================== */
function getSheet_(name) {
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name);
  if (!sh) throw new Error('ไม่พบชีท "' + name + '" — ใช้เมนู "⚙️ ติดตั้ง/สร้างชีตเริ่มต้น" ก่อน');
  return sh;
}
function getConfigSheet_() { return getSheet_(CONFIG_SHEET_NAME); }

function getHeaderColMap_(sheet) {
  var lastCol = sheet.getLastColumn();
  var headers = (lastCol > 0) ? sheet.getRange(1, 1, 1, lastCol).getValues()[0] : [];
  var map = {};
  headers.forEach(function (h, i) { var k = String(h || '').trim(); if (k) map[k] = i; });
  return { headers: headers, map: map };
}
function readRowObject_(sheet, rowNum, headerInfo) {
  var lastCol = sheet.getLastColumn();
  var vals = sheet.getRange(rowNum, 1, 1, lastCol).getValues()[0];
  var obj = {};
  headerInfo.headers.forEach(function (h, i) {
    var k = String(h || '').trim();
    if (k) obj[k] = (vals[i] === null || vals[i] === undefined) ? '' : vals[i];
  });
  return obj;
}
// แปลงค่าทุกคอลัมน์เป็นสตริง + ใส่นามแฝงชี้ไปยังค่าจริง
function buildDataMap_(rowObj, headers, aliasMap) {
  var dm = {};
  headers.forEach(function (h) {
    var k = String(h || '').trim(); if (!k) return;
    var v = rowObj[k];
    dm[k] = (v === null || v === undefined) ? '' : formatCellValue_(v);
  });
  Object.keys(aliasMap).forEach(function (from) { var to = aliasMap[from]; if (dm[to] !== undefined) dm[from] = dm[to]; });
  return dm;
}
function formatCellValue_(v) {
  if (Object.prototype.toString.call(v) === '[object Date]') {
    var tz = Session.getScriptTimeZone();
    return Utilities.formatDate(v, tz, 'd/M/yyyy');
  }
  return String(v).trim();
}

function getSettings_() {
  var sheet = getConfigSheet_();
  function val(row) { return String(sheet.getRange(row, 2).getValue() || '').trim(); }
  var folderId = val(1);
  if (!folderId || folderId.indexOf('<<') === 0) throw new Error('ยังไม่ได้ใส่ Output Folder ID ในชีท "ตั้งค่า" (ช่อง B1)');
  return {
    outputFolderId: folderId,
    nameField: val(2),                 // คอลัมน์ที่ใช้แสดงชื่อ/ตั้งชื่อโฟลเดอร์ย่อย (เว้นว่างได้)
    subfolder: (val(3) === 'ใช่')      // แยกโฟลเดอร์ย่อยตาม nameField
  };
}

function loadTemplates_() {
  var sheet = getSheet_(TEMPLATE_SHEET_NAME);
  var last = sheet.getLastRow();
  if (last < TEMPLATE_START_ROW) return [];
  var data = sheet.getRange(TEMPLATE_START_ROW, 1, last - TEMPLATE_START_ROW + 1, 3).getValues();
  var rows = [];
  data.forEach(function (r) {
    var name = String(r[0] || '').trim();
    var fileId = String(r[1] || '').trim();
    var pattern = String(r[2] || '').trim();
    if (!name) return;
    rows.push({ name: name, fileId: (fileId.indexOf('<<') === 0 ? '' : fileId), filePattern: pattern });
  });
  return rows;
}

function loadAliasMap_() {
  var map = {};
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(ALIAS_SHEET_NAME);
  if (sheet && sheet.getLastRow() >= 2) {
    var vals = sheet.getRange(2, 1, sheet.getLastRow() - 1, 2).getValues();
    vals.forEach(function (r) {
      var from = String(r[0] || '').trim(), to = String(r[1] || '').trim();
      if (from && to) map[from] = to;
    });
  }
  return map;
}

/* ===================== ชื่อไฟล์ / โฟลเดอร์ ===================== */
function resolveFilename_(pattern, dataMap, fallbackBase) {
  var name = '';
  if (pattern && pattern.indexOf('<<') !== 0) {
    name = pattern.replace(/\{\{\s*([^}]+?)\s*\}\}/g, function (m, k) {
      k = k.trim(); return (dataMap[k] !== undefined ? String(dataMap[k]) : '');
    });
  }
  name = sanitizeFileName_(name);
  if (!name) name = sanitizeFileName_(fallbackBase);
  return name;
}
function sanitizeFileName_(s) {
  return String(s || '').replace(/[\\\/:*?"<>|]/g, ' ').replace(/\s+/g, ' ').trim().substring(0, 150);
}
function getThaiDateSuffix_() {
  var now = new Date(), tz = Session.getScriptTimeZone();
  var d = Utilities.formatDate(now, tz, 'dd-MM');
  var be = Number(Utilities.formatDate(now, tz, 'yyyy')) + 543;
  return d + '-' + String(be).substring(2);
}
function getOrCreateSubfolder_(root, name) {
  name = sanitizeFileName_(name) || 'อื่นๆ';
  var it = root.getFoldersByName(name);
  return it.hasNext() ? it.next() : root.createFolder(name);
}

/* ===================== เลือกแถวที่จะทำ ===================== */
function getRowsToProcess_(sheet, headerInfo) {
  var checkboxIdx = headerInfo.map[CHECKBOX_COL_NAME];
  var lastRow = sheet.getLastRow();
  if (checkboxIdx !== undefined && lastRow >= 2) {
    var flags = sheet.getRange(2, checkboxIdx + 1, lastRow - 1, 1).getValues();
    var picked = [];
    flags.forEach(function (f, i) { if (f[0] === true) picked.push(i + 2); });
    if (picked.length) return { rows: picked, source: 'checkbox' };
  }
  // ไม่มี checkbox ติ๊ก -> ใช้แถวที่กำลังเลือก (ไฮไลต์) อยู่
  var sel = sheet.getActiveRange();
  var rows = [];
  if (sel) {
    var start = sel.getRow(), n = sel.getNumRows();
    for (var r = start; r < start + n; r++) if (r >= 2) rows.push(r);
  }
  if (!rows.length) throw new Error('ยังไม่ได้เลือกแถว — ติ๊ก Checkbox หรือคลิกเลือกแถวในชีท "ข้อมูล" ก่อน');
  return { rows: rows, source: 'selection' };
}

/* ===================== หน้าต่าง Merge ===================== */
function showMergeDialog() {
  getSheet_(DATA_SHEET_NAME); // ให้ error ชัดถ้ายังไม่ติดตั้ง
  var html = HtmlService.createHtmlOutputFromFile('MergeDialog').setWidth(470).setHeight(560);
  SpreadsheetApp.getUi().showModalDialog(html, 'สร้างเอกสารราชการ (ส่งออก Word)');
}

function getDialogInit() {
  var sheet = getSheet_(DATA_SHEET_NAME);
  var headerInfo = getHeaderColMap_(sheet);
  var picked = getRowsToProcess_(sheet, headerInfo);
  var settings = safeSettings_();
  var templates = loadTemplates_();
  var hasTemplateCol = headerInfo.map[TEMPLATE_COL_NAME] !== undefined;

  var lines = [];
  picked.rows.forEach(function (r) {
    var rowObj = readRowObject_(sheet, r, headerInfo);
    var label = settings.nameField && rowObj[settings.nameField] ? String(rowObj[settings.nameField]) : ('แถว ' + r);
    var tmpl = hasTemplateCol ? String(rowObj[TEMPLATE_COL_NAME] || '').trim() : '';
    var badge = tmpl ? ' <span class="pill">' + tmpl + '</span>' : '';
    lines.push('• ' + label + badge);
  });

  var src = (picked.source === 'checkbox') ? '☑️ จาก Checkbox' : '🖱️ จากแถวที่เลือก';
  return {
    rowInfoHtml: '<div style="margin-bottom:5px;color:#5f6368;font-size:12px">' + src + ' · ' + picked.rows.length + ' แถว</div>' + lines.join('<br>'),
    templates: templates.map(function (t) { return t.name; }),
    hasTemplateColumn: hasTemplateCol
  };
}
function safeSettings_() { try { return getSettings_(); } catch (e) { return { nameField: '', subfolder: false }; } }

function doMergeSelectedRows(chosenTemplate) {
  chosenTemplate = chosenTemplate || '';
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(DATA_SHEET_NAME);
  if (!sheet) throw new Error('ไม่พบชีท "' + DATA_SHEET_NAME + '"');

  var headerInfo = getHeaderColMap_(sheet);
  var picked = getRowsToProcess_(sheet, headerInfo);
  var settings = getSettings_();
  var templates = loadTemplates_();
  var byName = {}; templates.forEach(function (t) { byName[t.name] = t; });
  var aliasMap = loadAliasMap_();
  var rootFolder = DriveApp.getFolderById(settings.outputFolderId);
  var hasTemplateCol = headerInfo.map[TEMPLATE_COL_NAME] !== undefined;

  var blocks = [], okCount = 0, failCount = 0;

  picked.rows.forEach(function (r) {
    var rowObj = readRowObject_(sheet, r, headerInfo);
    var displayName = settings.nameField && rowObj[settings.nameField] ? String(rowObj[settings.nameField]) : ('แถว ' + r);
    var tmplName = chosenTemplate || (hasTemplateCol ? String(rowObj[TEMPLATE_COL_NAME] || '').trim() : '');

    var items = [], rowOk = false;
    if (!tmplName) {
      items.push('&nbsp;&nbsp;❌ ไม่ได้เลือกแม่แบบ (เลือกในหน้าต่าง หรือกรอกคอลัมน์ "' + TEMPLATE_COL_NAME + '")');
      failCount++;
    } else if (!byName[tmplName]) {
      items.push('&nbsp;&nbsp;❌ ไม่พบแม่แบบชื่อ "' + tmplName + '" ในชีท "' + TEMPLATE_SHEET_NAME + '"');
      failCount++;
    } else if (!byName[tmplName].fileId) {
      items.push('&nbsp;&nbsp;❌ แม่แบบ "' + tmplName + '" ยังไม่ได้กรอก File ID');
      failCount++;
    } else {
      try {
        var tmpl = byName[tmplName];
        var dataMap = buildDataMap_(rowObj, headerInfo.headers, aliasMap);
        var folder = rootFolder;
        if (settings.subfolder && settings.nameField && rowObj[settings.nameField]) {
          folder = getOrCreateSubfolder_(rootFolder, String(rowObj[settings.nameField]));
        }
        var outBase = resolveFilename_(tmpl.filePattern, dataMap, tmplName + '_' + getThaiDateSuffix_());
        var res = mergeDocxTemplate_(tmpl.fileId, dataMap, aliasMap, folder, outBase);

        var dlUrl = 'https://drive.google.com/uc?export=download&id=' + res.file.getId();
        var opUrl = res.file.getUrl();
        var warn = '';
        if (res.unknownFields.length) warn += '<br>&nbsp;&nbsp;&nbsp;&nbsp;<span class="warn">⚠️ MERGEFIELD ไม่รู้จัก: ' + res.unknownFields.join(', ') + '</span>';
        if (res.unresolved.length) warn += '<br>&nbsp;&nbsp;&nbsp;&nbsp;<span class="warn">⚠️ {{ }} ไม่พบคอลัมน์: ' + res.unresolved.join(', ') + '</span>';
        items.push('&nbsp;&nbsp;✅ ' + tmplName + ' <a class="dl" href="' + dlUrl + '" target="_blank">⬇️ ดาวน์โหลด Word</a> ' +
          '<a class="op" href="' + opUrl + '" target="_blank">เปิดใน Drive</a>' +
          '<br>&nbsp;&nbsp;&nbsp;&nbsp;<span class="fn">' + res.file.getName() + '</span>' + warn);
        okCount++; rowOk = true;
      } catch (e) {
        items.push('&nbsp;&nbsp;❌ ' + e.message);
        failCount++;
      }
    }

    blocks.push('<div class="res-item"><b>' + displayName + '</b><br>' + items.join('<br>') + '</div>');
    if (rowOk) markRowDone_(sheet, r, headerInfo);
    if (picked.source === 'checkbox') {
      var cc = headerInfo.map[CHECKBOX_COL_NAME];
      if (cc !== undefined) sheet.getRange(r, cc + 1).setValue(false);
    }
  });

  var bg = failCount ? '#fef7e0' : '#e6f4ea';
  var fg = failCount ? '#b06000' : '#188038';
  var icon = failCount ? '⚠️' : '🎉';
  var summary = '<div style="margin-bottom:10px;padding:10px 12px;border-radius:9px;background:' + bg +
    ';color:' + fg + ';font-weight:700">' + icon + ' สร้างสำเร็จ ' + okCount + ' ไฟล์' +
    (failCount ? (' · มีปัญหา ' + failCount + ' รายการ') : '') + '</div>';
  return summary + blocks.join('');
}

/* ===================== สแกนฟิลด์ในแม่แบบ ===================== */
function scanTemplateFields() {
  var ui = SpreadsheetApp.getUi();
  var templates = loadTemplates_();
  if (!templates.length) { ui.alert('ยังไม่มีแม่แบบในชีท "' + TEMPLATE_SHEET_NAME + '"'); return; }
  var sheet = getSheet_(DATA_SHEET_NAME);
  var headerInfo = getHeaderColMap_(sheet);
  var aliasMap = loadAliasMap_();

  var report = [];
  templates.forEach(function (t) {
    if (!t.fileId) { report.push('▪ ' + t.name + ': (ยังไม่ได้กรอก File ID)'); return; }
    var fields;
    try { fields = extractTemplateFields_(t.fileId); }
    catch (e) { report.push('▪ ' + t.name + ': อ่านไม่ได้ — ' + e.message); return; }
    var miss = fields.filter(function (f) {
      var real = aliasMap[f] || f;
      return headerInfo.map[real] === undefined && headerInfo.map[f] === undefined;
    });
    report.push('▪ ' + t.name + ': พบฟิลด์ ' + fields.length + ' รายการ' +
      (miss.length ? ('\n   ⚠️ ไม่ตรงหัวคอลัมน์: ' + miss.join(', ')) : '  ✅ ตรงครบ'));
  });
  ui.alert('ผลสแกนฟิลด์ในแม่แบบ', report.join('\n\n') +
    '\n\n(ฟิลด์ที่ไม่ตรง ให้แก้ชื่อในเทมเพลตให้ตรงหัวคอลัมน์ หรือเพิ่มคู่แมปในชีท "' + ALIAS_SHEET_NAME + '")',
    ui.ButtonSet.OK);
}

// ดึงชื่อฟิลด์ทั้งหมดจากเทมเพลต (MERGEFIELD + {{ }}) จาก document/header/footer
function extractTemplateFields_(fileId) {
  var blob = DriveApp.getFileById(fileId).getBlob().setContentType('application/zip');
  var blobs = Utilities.unzip(blob);
  var partRe = /^word\/(document|header\d*|footer\d*)\.xml$/;
  var set = {};
  blobs.forEach(function (b) {
    if (!partRe.test(b.getName())) return;
    var xml = b.getDataAsString('UTF-8');
    // MERGEFIELD: รวมข้อความ instrText ทั้งหมด แล้วแยกด้วยคำว่า MERGEFIELD
    var instr = '', mm, re = /<w:instrText[^>]*>([\s\S]*?)<\/w:instrText>/g;
    while ((mm = re.exec(xml)) !== null) instr += mm[1];
    instr.split(/MERGEFIELD/).forEach(function (seg, idx) {
      if (idx === 0) return;
      var name = seg.replace(/^\s+/, '');
      var cut = name.search(/[\\\r\n]|\s\s|<|\/\//); // ตัดที่ switch/ช่องว่างซ้อน
      if (cut > 0) name = name.substring(0, cut);
      name = name.trim().replace(/^"([\s\S]*?)"$/, '$1').trim();
      if (name) set[name] = true;
    });
    // {{ }}: ตัดแท็กออกก่อนแล้วค้นหา
    var plain = xml.replace(/<[^>]+>/g, '');
    var pm, pre = /\{\{\s*([^}]+?)\s*\}\}/g;
    while ((pm = pre.exec(plain)) !== null) set[pm[1].trim()] = true;
  });
  return Object.keys(set);
}

/* ===================== Checkbox / ทะเบียนคุม ===================== */
function columnToLetter_(col) {
  var s = ''; while (col > 0) { var r = (col - 1) % 26; s = String.fromCharCode(65 + r) + s; col = Math.floor((col - 1) / 26); } return s;
}
function ensureMinRows_(sheet, minRows) { var c = sheet.getMaxRows(); if (c < minRows) sheet.insertRowsAfter(c, minRows - c); }
function ensureMinCols_(sheet, minCols) { var c = sheet.getMaxColumns(); if (c < minCols) sheet.insertColumnsAfter(c, minCols - c); }

function addCheckboxColumn() {
  var ui = SpreadsheetApp.getUi();
  var sheet = getSheet_(DATA_SHEET_NAME);
  var headerInfo = getHeaderColMap_(sheet);
  if (headerInfo.map[CHECKBOX_COL_NAME] !== undefined) {
    ui.alert('มีคอลัมน์ "' + CHECKBOX_COL_NAME + '" อยู่แล้ว'); return;
  }
  var col = sheet.getLastColumn() + 1;
  ensureMinCols_(sheet, col);
  sheet.getRange(1, col).setValue(CHECKBOX_COL_NAME).setFontWeight('bold').setBackground('#e8eaed');
  var numRows = Math.max(sheet.getLastRow() - 1, 200);
  ensureMinRows_(sheet, numRows + 1);
  sheet.getRange(2, col, numRows, 1).insertCheckboxes();
  sheet.setColumnWidth(col, 70);
  ui.alert('เพิ่มคอลัมน์ "' + CHECKBOX_COL_NAME + '" ที่คอลัมน์ ' + columnToLetter_(col) + ' แล้ว ✅');
}

function setupTrackingColumns() {
  var ui = SpreadsheetApp.getUi();
  var sheet = getSheet_(DATA_SHEET_NAME);
  var headerInfo = getHeaderColMap_(sheet);
  var missing = TRACKING_COLUMNS.filter(function (c) { return headerInfo.map[c] === undefined; });
  if (missing.length === 0) { ui.alert('มีคอลัมน์ทะเบียนคุมครบอยู่แล้ว'); return; }

  var checkboxIdx = headerInfo.map[CHECKBOX_COL_NAME];
  var insertAt;
  if (checkboxIdx !== undefined) { insertAt = checkboxIdx + 1; sheet.insertColumns(insertAt, missing.length); }
  else { insertAt = sheet.getLastColumn() + 1; }

  var lastRow = Math.max(sheet.getLastRow(), 200);
  ensureMinRows_(sheet, lastRow);
  ensureMinCols_(sheet, insertAt + missing.length - 1);
  var numDataRows = lastRow - 1;

  var fresh = sheet.getRange(1, insertAt, lastRow, missing.length);
  fresh.clearDataValidations(); fresh.clearContent(); fresh.clearFormat();
  sheet.getRange(1, insertAt, 1, missing.length).setValues([missing]).setFontWeight('bold').setBackground('#e8eaed');

  var sIdx = missing.indexOf('สถานะ');
  if (sIdx !== -1) {
    var statusCol = insertAt + sIdx;
    var rule = SpreadsheetApp.newDataValidation().requireValueInList(STATUS_LIST, true).setAllowInvalid(true).build();
    sheet.getRange(2, statusCol, numDataRows, 1).setDataValidation(rule);
    sheet.setColumnWidth(statusCol, 130);
  }
  ['วันที่รับเรื่อง', 'กำหนดเสร็จ', 'วันที่ดำเนินการแล้วเสร็จ'].forEach(function (c) {
    var idx = missing.indexOf(c);
    if (idx !== -1) { sheet.getRange(2, insertAt + idx, numDataRows, 1).setNumberFormat('dd/mm/yyyy'); sheet.setColumnWidth(insertAt + idx, 120); }
  });
  var dueIdx = missing.indexOf('กำหนดเสร็จ'), recIdx = missing.indexOf('วันที่รับเรื่อง');
  if (dueIdx !== -1 && recIdx !== -1) {
    var dueCol = insertAt + dueIdx, recCol = insertAt + recIdx, off = recCol - dueCol, sla = getSlaDays_();
    sheet.getRange(2, dueCol, numDataRows, 1).setFormulaR1C1('=IF(RC[' + off + ']="","",RC[' + off + ']+' + sla + ')');
  }
  var noteIdx = missing.indexOf('หมายเหตุ');
  if (noteIdx !== -1) sheet.setColumnWidth(insertAt + noteIdx, 200);

  setupTrackingConditionalFormatting_(sheet, insertAt, missing);
  ui.alert('เพิ่มทะเบียนคุมเรียบร้อย ✅',
    'คอลัมน์: ' + missing.join(', ') + '\nSLA = ' + getSlaDays_() + ' วัน (ปรับได้ในชีท "ตั้งค่า")\n' +
    'กด Merge สำเร็จ ระบบจะตั้งสถานะ "' + STATUS_DONE + '" + วันที่ดำเนินการแล้วเสร็จ ให้อัตโนมัติ',
    ui.ButtonSet.OK);
}
function setupTrackingConditionalFormatting_(sheet, insertAt, missing) {
  var sIdx = missing.indexOf('สถานะ'), dIdx = missing.indexOf('กำหนดเสร็จ');
  if (sIdx === -1 || dIdx === -1) return;
  var sL = columnToLetter_(insertAt + sIdx), dL = columnToLetter_(insertAt + dIdx);
  var lastRow = Math.max(sheet.getLastRow(), 200);
  ensureMinRows_(sheet, lastRow);
  var range = sheet.getRange(2, 1, lastRow - 1, sheet.getLastColumn());
  var overdue = SpreadsheetApp.newConditionalFormatRule()
    .whenFormulaSatisfied('=AND($' + sL + '2<>"' + STATUS_DONE + '",$' + sL + '2<>"",$' + dL + '2<>"",$' + dL + '2<TODAY())')
    .setBackground('#f4c7c3').setRanges([range]).build();
  var near = SpreadsheetApp.newConditionalFormatRule()
    .whenFormulaSatisfied('=AND($' + sL + '2<>"' + STATUS_DONE + '",$' + sL + '2<>"",$' + dL + '2<>"",$' + dL + '2>=TODAY(),$' + dL + '2<=TODAY()+3)')
    .setBackground('#fce8b2').setRanges([range]).build();
  var rules = sheet.getConditionalFormatRules(); rules.push(overdue, near); sheet.setConditionalFormatRules(rules);
}
function getOrCreateSlaSetting_() {
  var sheet = getConfigSheet_(); var lastRow = sheet.getLastRow();
  if (lastRow >= 1) {
    var colA = sheet.getRange(1, 1, lastRow, 1).getValues();
    for (var i = 0; i < colA.length; i++) if (String(colA[i][0] || '').indexOf('SLA') !== -1)
      return { row: i + 1, value: sheet.getRange(i + 1, 2).getValue() };
  }
  var row = 5;
  sheet.getRange(row, 1).setValue('จำนวนวันที่ต้องดำเนินการให้แล้วเสร็จ (SLA)').setFontWeight('bold');
  sheet.getRange(row, 2).setValue(15).setBackground('#fff3cd');
  return { row: row, value: 15 };
}
function getSlaDays_() { var n = Number(getOrCreateSlaSetting_().value); return (n && n > 0) ? n : 15; }
function markRowDone_(sheet, rowNum, headerInfo) {
  var statusCol = headerInfo.map['สถานะ'], doneCol = headerInfo.map['วันที่ดำเนินการแล้วเสร็จ'];
  if (statusCol !== undefined) sheet.getRange(rowNum, statusCol + 1).setValue(STATUS_DONE);
  if (doneCol !== undefined) sheet.getRange(rowNum, doneCol + 1).setValue(new Date());
}

/* ===================== ติดตั้งชีตเริ่มต้น ===================== */
function initSheets() {
  var ui = SpreadsheetApp.getUi();
  var ss = SpreadsheetApp.getActiveSpreadsheet();

  // ชีท ตั้งค่า
  var cfg = ss.getSheetByName(CONFIG_SHEET_NAME) || ss.insertSheet(CONFIG_SHEET_NAME);
  cfg.clear();
  cfg.getRange(1, 1, 5, 2).setValues([
    ['Output Folder ID (โฟลเดอร์ Google Drive ที่เก็บผลลัพธ์)', '<< วาง Folder ID ที่นี่ >>'],
    ['คอลัมน์ที่ใช้แสดงชื่อ/ตั้งชื่อโฟลเดอร์ย่อย (เว้นว่างได้)', ''],
    ['แยกโฟลเดอร์ย่อยตามคอลัมน์ข้างบน (ใช่/ไม่)', 'ไม่'],
    ['', ''],
    ['จำนวนวันที่ต้องดำเนินการให้แล้วเสร็จ (SLA)', 15]
  ]);
  cfg.getRange(1, 1, 5, 1).setFontWeight('bold');
  cfg.getRange(1, 2).setBackground('#fff3cd');
  cfg.getRange(5, 2).setBackground('#fff3cd');
  cfg.setColumnWidth(1, 340); cfg.setColumnWidth(2, 300);

  // ชีท แม่แบบ
  var tpl = ss.getSheetByName(TEMPLATE_SHEET_NAME) || ss.insertSheet(TEMPLATE_SHEET_NAME);
  tpl.clear();
  tpl.getRange(1, 1, 1, 3).setValues([['ชื่อแม่แบบ', 'Drive File ID (.docx)', 'รูปแบบชื่อไฟล์ (ใส่ {{ฟิลด์}} ได้)']])
    .setFontWeight('bold').setBackground('#1a73e8').setFontColor('#ffffff');
  tpl.getRange(2, 1, 2, 3).setValues([
    ['คำสั่งแต่งตั้ง', '<< วาง File ID >>', 'คำสั่งที่ {{เลขที่คำสั่ง}} {{ชื่อเรื่อง}}'],
    ['หนังสือภายนอก', '<< วาง File ID >>', 'ที่ {{เลขที่หนังสือ}} {{ชื่อเรื่อง}}']
  ]);
  tpl.setColumnWidth(1, 160); tpl.setColumnWidth(2, 260); tpl.setColumnWidth(3, 320);
  tpl.setFrozenRows(1);

  // ชีท นามแฝงฟิลด์
  var al = ss.getSheetByName(ALIAS_SHEET_NAME) || ss.insertSheet(ALIAS_SHEET_NAME);
  al.clear();
  al.getRange(1, 1, 1, 2).setValues([['ชื่อฟิลด์ในเทมเพลต', 'หัวคอลัมน์จริงในชีท "ข้อมูล"']])
    .setFontWeight('bold').setBackground('#1a73e8').setFontColor('#ffffff');
  al.setColumnWidth(1, 240); al.setColumnWidth(2, 240); al.setFrozenRows(1);

  // ชีท ข้อมูล
  var data = ss.getSheetByName(DATA_SHEET_NAME) || ss.insertSheet(DATA_SHEET_NAME);
  if (data.getLastRow() === 0) {
    data.getRange(1, 1, 1, 6).setValues([[TEMPLATE_COL_NAME, 'เลขที่คำสั่ง', 'เลขที่หนังสือ', 'ชื่อเรื่อง', 'เรียน', 'วันที่']])
      .setFontWeight('bold').setBackground('#e8eaed');
    data.setFrozenRows(1);
    // dropdown แม่แบบ ในคอลัมน์ A
    var names = loadTemplates_().map(function (t) { return t.name; });
    if (names.length) {
      var rule = SpreadsheetApp.newDataValidation().requireValueInList(names, true).setAllowInvalid(true).build();
      data.getRange(2, 1, 200, 1).setDataValidation(rule);
    }
  }
  ss.setActiveSheet(data);
  ui.alert('สร้างชีตเริ่มต้นเรียบร้อย ✅',
    'ลำดับถัดไป:\n1) ใส่ Output Folder ID ในชีท "ตั้งค่า"\n2) ใส่แม่แบบ + File ID ในชีท "แม่แบบ"\n' +
    '3) กรอกข้อมูลในชีท "ข้อมูล"\n4) เมนู "➕ เพิ่มคอลัมน์ Checkbox" แล้วเริ่ม Merge ได้เลย',
    ui.ButtonSet.OK);
}

/* ===================== ตรวจความพร้อม ===================== */
function runHealthCheck() {
  var ui = SpreadsheetApp.getUi();
  var msg = [];
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  [DATA_SHEET_NAME, TEMPLATE_SHEET_NAME, CONFIG_SHEET_NAME].forEach(function (n) {
    msg.push((ss.getSheetByName(n) ? '✅' : '❌') + ' ชีท "' + n + '"');
  });
  try {
    var s = getSettings_(); msg.push('✅ Output Folder ID: ' + s.outputFolderId);
    try { DriveApp.getFolderById(s.outputFolderId); msg.push('✅ เข้าถึงโฟลเดอร์ผลลัพธ์ได้'); }
    catch (e) { msg.push('❌ เปิดโฟลเดอร์ผลลัพธ์ไม่ได้ (ตรวจ Folder ID/สิทธิ์)'); }
  } catch (e) { msg.push('❌ ' + e.message); }

  var templates = loadTemplates_();
  msg.push('— แม่แบบ ' + templates.length + ' รายการ —');
  templates.forEach(function (t) {
    if (!t.fileId) { msg.push('❌ ' + t.name + ': ยังไม่ได้กรอก File ID'); return; }
    try { DriveApp.getFileById(t.fileId); msg.push('✅ ' + t.name); }
    catch (e) { msg.push('❌ ' + t.name + ': File ID ผิดหรือไม่มีสิทธิ์'); }
  });
  var data = ss.getSheetByName(DATA_SHEET_NAME);
  if (data) {
    var hi = getHeaderColMap_(data);
    msg.push(hi.map[CHECKBOX_COL_NAME] !== undefined ? '✅ มีคอลัมน์ Checkbox' : 'ℹ️ ยังไม่มีคอลัมน์ Checkbox (เมนู ➕)');
  }
  ui.alert('ผลตรวจความพร้อม', msg.join('\n'), ui.ButtonSet.OK);
}

/* ===================================================================
 *  WEB APP  (doGet + API สำหรับหน้าเว็บ Index.html)
 *  ใช้ Google Sheet เดิมเป็นฐานข้อมูล + เครื่องยนต์ merge ตัวเดียวกัน
 * =================================================================== */

function doGet(e) {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('แพลตฟอร์มจัดทำเอกสารราชการ')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

// ข้อมูลตั้งต้นสำหรับหน้าเว็บ
function getWebInit() {
  var res = {
    ready: false, error: '', folderId: '', displayField: '',
    templates: [], headers: [], editableHeaders: [],
    hasTemplateColumn: false, trackingExists: false, rows: []
  };
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var data = ss.getSheetByName(DATA_SHEET_NAME);
  if (!data) { res.error = 'ยังไม่ได้ติดตั้งชีต "' + DATA_SHEET_NAME + '" — เปิดสเปรดชีตแล้วใช้เมนู ⚙️ ติดตั้ง/สร้างชีตเริ่มต้น'; return res; }

  var hi = getHeaderColMap_(data);
  res.headers = hi.headers.map(function (h) { return String(h || '').trim(); }).filter(function (h) { return h; });
  var skip = {}; skip[CHECKBOX_COL_NAME] = 1; TRACKING_COLUMNS.forEach(function (c) { skip[c] = 1; });
  res.editableHeaders = res.headers.filter(function (h) { return !skip[h]; });
  res.hasTemplateColumn = hi.map[TEMPLATE_COL_NAME] !== undefined;
  res.trackingExists = hi.map['สถานะ'] !== undefined;

  var settings = null;
  try { settings = getSettings_(); res.ready = true; res.displayField = settings.nameField; res.folderId = settings.outputFolderId; }
  catch (err) { res.error = err.message; }

  res.templates = loadTemplates_().map(function (t) { return { name: t.name, hasFileId: !!t.fileId }; });

  var last = data.getLastRow();
  if (last >= 2) {
    var maxRow = Math.min(last, 501); // จำกัด 500 แถวแรกเพื่อความเร็ว
    for (var r = 2; r <= maxRow; r++) {
      var obj = readRowObject_(data, r, hi);
      var nonEmpty = res.editableHeaders.some(function (h) { return String(obj[h] || '').trim() !== ''; });
      if (!nonEmpty) continue;
      var label = (settings && settings.nameField && obj[settings.nameField])
        ? String(obj[settings.nameField]) : firstNonEmpty_(obj, res.editableHeaders, r);
      res.rows.push({
        id: r,
        label: label,
        template: res.hasTemplateColumn ? String(obj[TEMPLATE_COL_NAME] || '').trim() : '',
        status: res.trackingExists ? String(obj['สถานะ'] || '') : ''
      });
    }
  }
  return res;
}
function firstNonEmpty_(obj, headers, r) {
  for (var i = 0; i < headers.length; i++) {
    if (headers[i] === TEMPLATE_COL_NAME) continue;
    var v = formatCellValue_(obj[headers[i]]);
    if (v) return v;
  }
  return 'แถว ' + r;
}

// สร้างเอกสารจากรายการแถวที่เลือกในหน้าเว็บ -> คืนผลเป็นข้อมูล (ให้ฝั่งเว็บ render เอง)
function webGenerate(rowIds, chosenTemplate) {
  chosenTemplate = chosenTemplate || '';
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(DATA_SHEET_NAME);
  if (!sheet) throw new Error('ไม่พบชีท "' + DATA_SHEET_NAME + '"');
  var hi = getHeaderColMap_(sheet);
  var settings = getSettings_();
  var byName = {}; loadTemplates_().forEach(function (t) { byName[t.name] = t; });
  var aliasMap = loadAliasMap_();
  var root = DriveApp.getFolderById(settings.outputFolderId);
  var hasCol = hi.map[TEMPLATE_COL_NAME] !== undefined;

  var out = [];
  (rowIds || []).forEach(function (r) {
    r = Number(r);
    var obj = readRowObject_(sheet, r, hi);
    var label = (settings.nameField && obj[settings.nameField]) ? String(obj[settings.nameField]) : ('แถว ' + r);
    var tmplName = chosenTemplate || (hasCol ? String(obj[TEMPLATE_COL_NAME] || '').trim() : '');
    try {
      if (!tmplName) throw new Error('ไม่ได้เลือกแม่แบบ');
      var tmpl = byName[tmplName];
      if (!tmpl) throw new Error('ไม่พบแม่แบบ "' + tmplName + '"');
      if (!tmpl.fileId) throw new Error('แม่แบบ "' + tmplName + '" ยังไม่ได้กรอก File ID');
      var dataMap = buildDataMap_(obj, hi.headers, aliasMap);
      var folder = root;
      if (settings.subfolder && settings.nameField && obj[settings.nameField]) folder = getOrCreateSubfolder_(root, String(obj[settings.nameField]));
      var outBase = resolveFilename_(tmpl.filePattern, dataMap, tmplName + '_' + getThaiDateSuffix_());
      var res = mergeDocxTemplate_(tmpl.fileId, dataMap, aliasMap, folder, outBase);
      markRowDone_(sheet, r, hi);
      out.push({
        rowId: r, ok: true, label: label, templateName: tmplName, fileName: res.file.getName(),
        downloadUrl: 'https://drive.google.com/uc?export=download&id=' + res.file.getId(),
        driveUrl: res.file.getUrl(), unknownFields: res.unknownFields, unresolved: res.unresolved
      });
    } catch (err) {
      out.push({ rowId: r, ok: false, label: label, templateName: tmplName, error: err.message });
    }
  });
  return out;
}

// เพิ่มข้อมูล 1 แถวลงชีท "ข้อมูล" จากฟอร์มในหน้าเว็บ -> คืนเลขแถว
function webAddRow(values) {
  var sheet = getSheet_(DATA_SHEET_NAME);
  var hi = getHeaderColMap_(sheet);
  var row = [];
  for (var i = 0; i < hi.headers.length; i++) row.push('');
  Object.keys(values || {}).forEach(function (k) { if (hi.map[k] !== undefined) row[hi.map[k]] = values[k]; });
  sheet.appendRow(row);
  return sheet.getLastRow();
}

// บันทึกลงชีท + สร้างเอกสารทันที
function webCreateAndGenerate(values, chosenTemplate) {
  var id = webAddRow(values);
  var tmpl = chosenTemplate || (values && values[TEMPLATE_COL_NAME]) || '';
  return webGenerate([id], tmpl);
}

// สแกนฟิลด์ของแม่แบบเดียว (สำหรับแท็บเครื่องมือ)
function webScanTemplate(name) {
  var t = null; loadTemplates_().forEach(function (x) { if (x.name === name) t = x; });
  if (!t) throw new Error('ไม่พบแม่แบบ "' + name + '"');
  if (!t.fileId) throw new Error('แม่แบบนี้ยังไม่ได้กรอก File ID');
  var fields = extractTemplateFields_(t.fileId);
  var hi = getHeaderColMap_(getSheet_(DATA_SHEET_NAME));
  var aliasMap = loadAliasMap_();
  var missing = fields.filter(function (f) { var real = aliasMap[f] || f; return hi.map[real] === undefined && hi.map[f] === undefined; });
  return { fields: fields, missing: missing };
}

// ตรวจความพร้อม (คืนเป็นรายการ)
function webHealth() {
  var checks = []; var ss = SpreadsheetApp.getActiveSpreadsheet();
  [DATA_SHEET_NAME, TEMPLATE_SHEET_NAME, CONFIG_SHEET_NAME].forEach(function (n) { checks.push({ label: 'ชีท "' + n + '"', ok: !!ss.getSheetByName(n) }); });
  try {
    var s = getSettings_(); checks.push({ label: 'Output Folder ID', ok: true });
    try { DriveApp.getFolderById(s.outputFolderId); checks.push({ label: 'เข้าถึงโฟลเดอร์ผลลัพธ์', ok: true }); }
    catch (e) { checks.push({ label: 'เข้าถึงโฟลเดอร์ผลลัพธ์', ok: false }); }
  } catch (e) { checks.push({ label: e.message, ok: false }); }
  loadTemplates_().forEach(function (t) {
    if (!t.fileId) { checks.push({ label: 'แม่แบบ ' + t.name + ' (ยังไม่มี File ID)', ok: false }); return; }
    try { DriveApp.getFileById(t.fileId); checks.push({ label: 'แม่แบบ ' + t.name, ok: true }); }
    catch (e) { checks.push({ label: 'แม่แบบ ' + t.name + ' (File ID ผิด/ไม่มีสิทธิ์)', ok: false }); }
  });
  return checks;
}

// URL ของสเปรดชีต (ให้ปุ่ม "เปิดสเปรดชีต" ในหน้าเว็บ)
function webSpreadsheetUrl() { return SpreadsheetApp.getActiveSpreadsheet().getUrl(); }
